function varargout = MCEE(varargin)
% MCEE MATLAB code for MCEE.fig
%      MCEE, by itself, creates a new MCEE or raises the existing
%      singleton*.
%
%      H = MCEE returns the handle to a new MCEE or the handle to
%      the existing singleton*.
%
%      MCEE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MCEE.M with the given input arguments.
%
%      MCEE('Property','Value',...) creates a new MCEE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MCEE_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MCEE_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MCEE

% Last Modified by GUIDE v2.5 25-Mar-2018 11:25:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MCEE_OpeningFcn, ...
                   'gui_OutputFcn',  @MCEE_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MCEE is made visible.
function MCEE_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MCEE (see VARARGIN)

% Choose default command line output for MCEE
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MCEE wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MCEE_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
% --- Executes on button press in pushbutton2.

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile('*.xls', 'Select your excel');
str=[pathname,filename];
Meta=xlsread(str);
handles.Meta = Meta;
guidata(hObject,handles);%%%���ȫ�ֱ���
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
open('Processing.fig');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ss=str2double(get(handles.edit1,'string')); 
data=handles.Meta;
col=size(data,2);
obj.Y=data(:,1);
obj.F=data(:,2);
obj.M=data(:,3:col);
tic
 c=size(obj.M,2);
       cc=size(obj.Y,2);
       ccc=size(obj.F,2);
       Pcrude_n=zeros(c,ccc);% p values from normal model
       Pcrude_p=zeros(c,ccc);
       Pcrude_ig=zeros(c,ccc);
       Pcrude_g=zeros(c,ccc);
       for i=1:c
           x=obj.M(:,i);
           for j=1:ccc
              y=obj.F(:,j);
              b_n = glmfit(x,y,'normal');
              yfit_n = glmval(b_n,x,'identity');
              [~, p_n] = chi2gof(yfit_n);
              Pcrude_n(i,j)=p_n;
              
              b_p = glmfit(x,y,'poisson');
              yfit_p = glmval(b_p,x,'log');
              [~, p_p] = chi2gof(yfit_p);
              Pcrude_p(i,j)=p_p;
              
              b_ig = glmfit(x,y,'inverse gaussian');
              yfit_ig = glmval(b_ig,x,-2);
              [~, p_ig] = chi2gof(yfit_ig);
              Pcrude_ig(i,j)=p_ig;
              
              b_g = glmfit(x,y,'gamma');
              yfit_g = glmval(b_g,x,'reciprocal');
              [~, p_g] = chi2gof(yfit_g);
              Pcrude_g(i,j)=p_g;
           end
      end
      d_n=Pcrude_n<0.01;
      d_p=Pcrude_p<0.01;
      d_ig=Pcrude_ig<0.01;
      d_g=Pcrude_g<0.01;
      d=d_n+d_p+d_ig+d_g;% variables with p<0.01 from any one of the 4 models were labeled 1.
      inx0=find(sum(d,2)>=ss);  % indexes of variables related to F (union of all factors). Some of them were also related to Y.
     
      inx00=inx0;
      siz=size(obj.Y);
      sizz=siz(2);
      allinx=cell(size(obj.M,2),sizz*2)
      h=guihandles;
      set(h.output1,'string','||||||||||||||||')%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������
      for isize=1:sizz
          for i12=1:2
      group11=find(obj.Y(:,isize)==i12);
      Y11=obj.Y(group11,:);
      F11=obj.F(group11,:);
      M11=obj.M(group11,:);
       c11=size(M11,2);
       cc11=size(Y11,2);
       ccc11=size(F11,2);
       Pcrude_n11=zeros(c11,ccc11);% p values from normal model
       Pcrude_p11=zeros(c11,ccc11);
       Pcrude_ig11=zeros(c11,ccc11);
       Pcrude_g11=zeros(c11,ccc11);
       for i11=1:c11
           x11=M11(:,i11);
           for j11=1:ccc11
              y11=F11(:,j11);
              b_n11 = glmfit(x11,y11,'normal');
              yfit_n11 = glmval(b_n11,x11,'identity');
              [~, p_n11] = chi2gof(yfit_n11);
              Pcrude_n11(i11,j11)=p_n11;
              
              b_p11 = glmfit(x11,y11,'poisson');
              yfit_p11 = glmval(b_p11,x11,'log');
              [~, p_p11] = chi2gof(yfit_p11);
              Pcrude_p11(i11,j11)=p_p11;
              
              b_ig11 = glmfit(x11,y11,'inverse gaussian');
              yfit_ig11 = glmval(b_ig11,x11,-2);
              [~, p_ig11] = chi2gof(yfit_ig11);
              Pcrude_ig11(i11,j11)=p_ig11;
              
              b_g11 = glmfit(x11,y11,'gamma');
              yfit_g11 = glmval(b_g11,x11,'reciprocal');
              [~, p_g11] = chi2gof(yfit_g11);
              Pcrude_g11(i11,j11)=p_g11;
           end
      end
      d_n11=Pcrude_n11<0.01;
      d_p11=Pcrude_p11<0.01;
      d_ig11=Pcrude_ig11<0.01;
      d_g11=Pcrude_g11<0.01;
      d11=d_n11+d_p11+d_ig11+d_g11;% variables with p<0.01 from any one of the 4 models were labeled 1.
      inx11=find(sum(d11,2)>=ss);     
      inx00= union(inx00,inx11)   
          
          end
      end
     inx=union(inx0,inx00);
      h=guihandles;
      set(h.output2,'string','||||||||||||||||')%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������
     %%%%            GLM on M and Y
     for i22=1:c
           x22=obj.M(:,i22);
               for j22=1:cc
              y22=obj.Y(:,j22);
              b_n22 = glmfit(x22,y22,'normal');
              yfit_n22 = glmval(b_n22,x22,'identity');
              [~, p_n22] = chi2gof(yfit_n22);
              Pcrude_n22(i22,j22)=p_n22;
              
              b_p22 = glmfit(x22,y22,'poisson');
              yfit_p22 = glmval(b_p22,x22,'log');
              [~, p_p22] = chi2gof(yfit_p22);
              Pcrude_p22(i22,j22)=p_p22;
              
              b_ig22 = glmfit(x22,y22,'inverse gaussian');
              yfit_ig22 = glmval(b_ig22,x22,-2);
              [~, p_ig22] = chi2gof(yfit_ig22);
              Pcrude_ig22(i22,j22)=p_ig22;
              
              b_g22 = glmfit(x22,y22,'gamma');
              yfit_g22 = glmval(b_g22,x22,'reciprocal');
              [~, p_g22] = chi2gof(yfit_g22);
              Pcrude_g22(i22,j22)=p_g22;
              
         
           end
      end
      d_n22=Pcrude_n22<0.01;
      d_p22=Pcrude_p22<0.01;
      d_ig22=Pcrude_ig22<0.01;
      d_g22=Pcrude_g22<0.01;
      d22=d_n22+d_p22+d_ig22+d_g22;% variables with p<0.01 from any one of the 4 models were labeled 1.
      h=guihandles;
      set(h.output3,'string','||||||||||||||||')%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������
      for j22=1:cc
      inx22=find(d22(:,cc)>=1);    
            pp(:,1)=inx22;
      pp(:,2)=Pcrude_n22(inx22,cc);
      pp(:,3)=Pcrude_p22(inx22,cc);
      pp(:,4)=Pcrude_ig22(inx22,cc);
      pp(:,5)=Pcrude_g22(inx22,cc);
      pp0 = pp(:,2:5);
      pp(:,6)=mean(pp0,2);
      [~,index]=sort(pp(:,6));
       pp1=pp(index,:);
       number=round(ss*size(pp1,1));
       pp2=pp1(1:number,1);
       pp3=intersect(inx,pp2);
       inx(ismember(inx,pp3))=[];
      end
      h=guihandles;
      set(h.output4,'string','||||||||||||||||')%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������
      %% remove factor-related component from best fitted model, and model selection was done by R2     
        % model selection
        B=[];
        YFIT=[];
        I=[];
        RSQ=[];
        for i=1:length(inx)
            xx=[obj.Y,obj.F];
            yy=obj.M(:,inx(i));
            b1=glmfit(xx,yy,'normal');% normal distribution
            yfit1 = glmval(b1,xx,'identity');
        %     [h, p] = chi2gof(yfit);
            yresid1 = yy - yfit1;
            SSresid1 = sum(yresid1.^2);
            SStotal1 = (length(yy)-1) * var(yy);
            rsq1 = 1 - SSresid1/SStotal1;

            b2=glmfit(xx,yy,'poisson');% poisson distribution
            yfit2 = glmval(b2,xx,'log');
        %     [h, p] = chi2gof(yfit);
            yresid2 = yy - yfit2;
            SSresid2 = sum(yresid2.^2);
            SStotal2 = (length(yy)-1) * var(yy);
            rsq2 = 1 - SSresid2/SStotal2;

            b3=glmfit(xx,yy,'inverse gaussian');% inverse gaussian distribution
            yfit3 = glmval(b3,xx,-2);
        %     [h, p] = chi2gof(yfit);
            yresid3 = yy - yfit3;
            SSresid3 = sum(yresid3.^2);
            SStotal3 = (length(yy)-1) * var(yy);
            rsq3 = 1 - SSresid3/SStotal3;

            b4=glmfit(xx,yy,'gamma');% gamma distribution
            yfit4 = glmval(b4,xx,'reciprocal');
        %     [h, p] = chi2gof(yfit);
            yresid4 = yy - yfit4;
            SSresid4 = sum(yresid4.^2);
            SStotal4 = (length(yy)-1) * var(yy);
            rsq4 = 1 - SSresid4/SStotal4;

            R2=[rsq1,rsq2,rsq3,rsq4];
            [rsq,index]=max(R2);
            RSQ=[RSQ,rsq];
            I=[I,index];
           % final model saved in B and YFIT
            switch index 
                case 1
                    B=[B,b1];
                    YFIT=[YFIT,yfit1];
                    submode='normal';
                case 2
                     B=[B,b2];
                    YFIT=[YFIT,yfit2];
                    submode='poisson';
                case 3
                      B=[B,b3];
                    YFIT=[YFIT,yfit3];
                    submode='inverse gaussian';
                case 4
                      B=[B,b4];
                    YFIT=[YFIT,yfit4];
                    submode='gamma';
                otherwise
                warning('Model selection failed!');
            end
        end
        
       obj.T=obj.M(:,inx);% variables need revision
       obj.Z=obj.M;% corrected data
       for i=1:length(inx)
           for j=1:ccc
                     obj.Z(:,inx(i))=obj.Z(:,inx(i))-B((j+1),i)*obj.F(:,j);
               
           end
       end
        obj.timeCPU.GLM = toc;
        result.T=obj.T;
        result.Z=obj.Z;
        %% add the abs(min) of each column
min_z=min(result.Z);
for i=1:size(obj.Z,2)
   a=find(result.Z(:,i)<0);
   if(a)
       result.Z(:,i)= result.Z(:,i)+abs(min_z(i));
   end
end
xlswrite('MCEE.xls',result.Z);
handles.obj = obj;
handles.result=result;
guidata(hObject,handles);%%%���ȫ�ֱ���
h=guihandles;
set(h.output5,'string','||||||||||||||||')%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������
set(h.output6,'string','The result has been saved to the folder')




% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
obj=handles.obj;
result=handles.result;
var=get(handles.popupmenu1,'value');
axes(handles.axes1);
% x=0:0.01:2*pi;
 switch var
case 1
    [~,scoreB,latentB] = princomp(zscore(obj.M));%% before
     group1=find(obj.Y(:,1)==1);
     group2=find(obj.Y(:,1)==2);
    scatter(obj.M(:,1),obj.M(:,2));        
    plot(scoreB(group1,1),scoreB(group1,2),'sr','MarkerFaceColor','r');
    hold on;
    plot(scoreB(group2,1),scoreB(group2,2),'ob','MarkerFaceColor','b');
    legend(['Y' num2str(1) '=1'],['Y' num2str(1) '=2']);
    xlabel('PC1');
    ylabel('PC2');
    hold off;
case 2
[~,scoreA,latentA] = princomp(zscore(result.Z));% after
 Ygroup1=find(obj.Y(:,1)==1);
 Ygroup2=find(obj.Y(:,1)==2);
 plot(scoreA(Ygroup1,1),scoreA(Ygroup1,2),'sr','MarkerFaceColor','r');
  hold on;
  plot(scoreA(Ygroup2,1),scoreA(Ygroup2,2),'ob','MarkerFaceColor','b');
  legend(['Y' num2str(1) '=1'],['Y' num2str(1) '=2']);
    xlabel('PC1');
    ylabel('PC2');
  hold off;
end
 axis1 equal
% --- Executes during object creation, after setting all properties.

function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(MCEE)
